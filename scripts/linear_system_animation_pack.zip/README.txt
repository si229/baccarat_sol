二元一次方程组动画解析 - 使用说明

内容：
1. index.html：动画讲解页面
2. start_animation.bat：Windows 启动脚本

在新的 Windows 环境中播放：
1. 解压整个文件夹。
2. 双击 start_animation.bat。
3. 系统会用默认浏览器打开动画页面。

也可以直接双击 index.html 播放。

本版已补充方程组大括号，并移除了下方坐标图展示。
